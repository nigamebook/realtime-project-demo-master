package com.cloudtechmasters.realtimeprojectdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RealtimeProjectDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
